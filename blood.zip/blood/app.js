const express = require("express")
const path = require('path');
const app = express();
const port = 1000;

const mongoose = require('mongoose');
main().catch(err => console.log(err));
async function main() {
    await mongoose.connect('mongodb://localhost/services');
}

//Mongoose Schcema
const serviceSchema = new mongoose.Schema({
    name: String,
    phone: Number,
    address: String,
    age: Number,
    bg: String,
    disease: String
});

//Model
var Service = mongoose.model('Service', serviceSchema);

//Express secific 
app.use('/static', express.static('static'))
app.use(express.urlencoded())

//Pug secific 
app.set('view engine', 'pug')
app.set('views', path.join(__dirname, 'views'))

app.get('/', (req, res) => {
    res.status(200).render('index.pug');
})

app.get('/services', (req, res) => {
    res.status(200).render('services.pug');
})

app.get('/about', (req, res) => {
    res.status(200).render('about.pug');
})

app.post('/services', (req, res) => {
    var data = new Service(req.body);
    data.save().then(() => {
        res.send("Data saved successfully")
    }).catch(() => {
        res.status(400).send("Sorry request failed\nCheck your input data before submitting...")
    })
});

app.get('/contact', (req, res) => {
    res.status(200).render('contact.pug');

})

//Starting Server
app.listen(port, () => {
    console.log("Application started successfully")
})